        function saibaMais(){
        var pontos=document.getElementById("pontos");
        var maisTexto=document.getElementById("mais");
        var btnSaibaMais=document.getElementById("btnSaibaMais");

        if(pontos.style.display==="none"){
        pontos.style.display="inline";
        maisTexto.style.display="none";
        btnSaibaMais.innerHTML="Expandir";
        }else{
        pontos.style.display="none";
        maisTexto.style.display="inline";
        btnSaibaMais.innerHTML="Minimizar";
        }
        }

        function saibaMais2(){
        var pontos=document.getElementById("pontos2");
        var maisTexto=document.getElementById("mais2");
        var btnSaibaMais=document.getElementById("btnSaibaMais2");

        if(pontos.style.display==="none"){
        pontos.style.display="inline";
        maisTexto.style.display="none";
        btnSaibaMais.innerHTML="Expandir";
        }else{
        pontos.style.display="none";
        maisTexto.style.display="inline";
        btnSaibaMais.innerHTML="Minimizar";
        }
        }

        function saibaMais3(){
        var pontos=document.getElementById("pontos3");
        var maisTexto=document.getElementById("mais3");
        var btnSaibaMais=document.getElementById("btnSaibaMais3");

        if(pontos.style.display==="none"){
        pontos.style.display="inline";
        maisTexto.style.display="none";
        btnSaibaMais.innerHTML="Expandir";
        }else{
        pontos.style.display="none";
        maisTexto.style.display="inline";
        btnSaibaMais.innerHTML="Minimizar";
        }
        }
